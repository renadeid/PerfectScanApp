-- PerfectScan payroll & expenses schema.
-- Run once against your Postgres database (see scripts/migrate.mjs / `npm run db:migrate`).

-- Needed for gen_random_uuid() on Postgres < 16 (harmless no-op on newer versions).
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS employees (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            TEXT NOT NULL,
  role            TEXT NOT NULL CHECK (role IN ('doctor', 'staff')),
  pay_type        TEXT CHECK (pay_type IN ('shift', 'percentage') OR pay_type IS NULL),
  base_salary     NUMERIC(12, 2) NOT NULL DEFAULT 0,
  shift_rate      NUMERIC(12, 2) NOT NULL DEFAULT 0,
  percentage_rate NUMERIC(6, 3) NOT NULL DEFAULT 0,
  phone           TEXT NOT NULL DEFAULT '',
  active          BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payroll_entries (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id  UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  month        TEXT NOT NULL, -- 'YYYY-MM'
  shifts       NUMERIC(6, 2) NOT NULL DEFAULT 0,
  revenue      NUMERIC(12, 2) NOT NULL DEFAULT 0,
  bonus        NUMERIC(12, 2) NOT NULL DEFAULT 0,
  deductions   NUMERIC(12, 2) NOT NULL DEFAULT 0,
  advance      NUMERIC(12, 2) NOT NULL DEFAULT 0,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (employee_id, month)
);

CREATE TABLE IF NOT EXISTS expenses (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date        DATE NOT NULL,
  type        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  amount      NUMERIC(12, 2) NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_payroll_month ON payroll_entries(month);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date);
