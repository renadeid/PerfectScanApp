import { neon } from "@neondatabase/serverless";
import type { Employee, Expense, PayrollEntry, ExpenseType } from "./types";

/**
 * Lazily-created query function. Reading env vars at call time (not at
 * module load) means a missing connection string surfaces as a normal
 * caught error from an API route, instead of crashing `next build` while
 * it type-checks/collects the route modules.
 */
let _sql: ReturnType<typeof neon> | null = null;
function sql(strings: TemplateStringsArray, ...values: unknown[]): Promise<Record<string, any>[]> {
  if (!_sql) {
    const connectionString = process.env.DATABASE_URL || process.env.POSTGRES_URL;
    if (!connectionString) {
      throw new Error(
        "No DATABASE_URL (or POSTGRES_URL) environment variable set. Add a Postgres database in the Vercel Storage tab, or set one in .env for local development."
      );
    }
    _sql = neon(connectionString);
  }
  return _sql(strings, ...values) as Promise<Record<string, any>[]>;
}

/**
 * Thin data-access layer over the three tables in db/schema.sql.
 * Every route handler goes through here rather than writing SQL inline,
 * so the row <-> app-shape mapping (snake_case columns -> camelCase
 * fields, numeric strings -> numbers) lives in exactly one place.
 */

function toEmployee(row: any): Employee {
  return {
    id: row.id,
    name: row.name,
    role: row.role,
    payType: row.pay_type,
    baseSalary: Number(row.base_salary),
    shiftRate: Number(row.shift_rate),
    percentageRate: Number(row.percentage_rate),
    phone: row.phone,
    active: row.active,
    createdAt: row.created_at,
  };
}

function toPayrollEntry(row: any): PayrollEntry {
  return {
    id: row.id,
    employeeId: row.employee_id,
    month: row.month,
    shifts: Number(row.shifts),
    revenue: Number(row.revenue),
    bonus: Number(row.bonus),
    deductions: Number(row.deductions),
    advance: Number(row.advance),
    updatedAt: row.updated_at,
  };
}

function toExpense(row: any): Expense {
  return {
    id: row.id,
    date: typeof row.date === "string" ? row.date : row.date.toISOString().slice(0, 10),
    type: row.type,
    description: row.description,
    amount: Number(row.amount),
    createdAt: row.created_at,
  };
}

export async function listEmployees(): Promise<Employee[]> {
  const rows = await sql`SELECT * FROM employees ORDER BY created_at ASC`;
  return rows.map(toEmployee);
}

export async function createEmployee(input: {
  name: string;
  role: "doctor" | "staff";
  payType: "shift" | "percentage" | null;
  baseSalary: number;
  shiftRate: number;
  percentageRate: number;
  phone: string;
  active: boolean;
}): Promise<Employee> {
  const rows = await sql`
    INSERT INTO employees (name, role, pay_type, base_salary, shift_rate, percentage_rate, phone, active)
    VALUES (${input.name}, ${input.role}, ${input.payType}, ${input.baseSalary}, ${input.shiftRate}, ${input.percentageRate}, ${input.phone}, ${input.active})
    RETURNING *
  `;
  return toEmployee(rows[0]);
}

export async function updateEmployee(
  id: string,
  input: {
    name: string;
    role: "doctor" | "staff";
    payType: "shift" | "percentage" | null;
    baseSalary: number;
    shiftRate: number;
    percentageRate: number;
    phone: string;
    active: boolean;
  }
): Promise<Employee | null> {
  const rows = await sql`
    UPDATE employees SET
      name = ${input.name},
      role = ${input.role},
      pay_type = ${input.payType},
      base_salary = ${input.baseSalary},
      shift_rate = ${input.shiftRate},
      percentage_rate = ${input.percentageRate},
      phone = ${input.phone},
      active = ${input.active}
    WHERE id = ${id}
    RETURNING *
  `;
  return rows[0] ? toEmployee(rows[0]) : null;
}

export async function deleteEmployee(id: string): Promise<void> {
  // payroll_entries has ON DELETE CASCADE on employee_id.
  await sql`DELETE FROM employees WHERE id = ${id}`;
}

export async function listPayrollEntries(): Promise<PayrollEntry[]> {
  const rows = await sql`SELECT * FROM payroll_entries`;
  return rows.map(toPayrollEntry);
}

/** Insert or update the single payroll row for (employeeId, month). */
export async function upsertPayrollEntry(input: {
  employeeId: string;
  month: string;
  shifts: number;
  revenue: number;
  bonus: number;
  deductions: number;
  advance: number;
}): Promise<PayrollEntry> {
  const rows = await sql`
    INSERT INTO payroll_entries (employee_id, month, shifts, revenue, bonus, deductions, advance, updated_at)
    VALUES (${input.employeeId}, ${input.month}, ${input.shifts}, ${input.revenue}, ${input.bonus}, ${input.deductions}, ${input.advance}, now())
    ON CONFLICT (employee_id, month) DO UPDATE SET
      shifts = EXCLUDED.shifts,
      revenue = EXCLUDED.revenue,
      bonus = EXCLUDED.bonus,
      deductions = EXCLUDED.deductions,
      advance = EXCLUDED.advance,
      updated_at = now()
    RETURNING *
  `;
  return toPayrollEntry(rows[0]);
}

export async function listExpenses(): Promise<Expense[]> {
  const rows = await sql`SELECT * FROM expenses ORDER BY date DESC, created_at DESC`;
  return rows.map(toExpense);
}

export async function createExpense(input: {
  date: string;
  type: ExpenseType;
  description: string;
  amount: number;
}): Promise<Expense> {
  const rows = await sql`
    INSERT INTO expenses (date, type, description, amount)
    VALUES (${input.date}, ${input.type}, ${input.description}, ${input.amount})
    RETURNING *
  `;
  return toExpense(rows[0]);
}

export async function updateExpense(
  id: string,
  input: { date: string; type: ExpenseType; description: string; amount: number }
): Promise<Expense | null> {
  const rows = await sql`
    UPDATE expenses SET date = ${input.date}, type = ${input.type}, description = ${input.description}, amount = ${input.amount}
    WHERE id = ${id}
    RETURNING *
  `;
  return rows[0] ? toExpense(rows[0]) : null;
}

export async function deleteExpense(id: string): Promise<void> {
  await sql`DELETE FROM expenses WHERE id = ${id}`;
}

/** Cheap connectivity check for /api/health. */
export async function ping(): Promise<void> {
  await sql`SELECT 1`;
}
