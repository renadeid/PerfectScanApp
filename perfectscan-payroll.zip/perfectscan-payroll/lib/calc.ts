import type { Employee, PayrollEntry } from "./types";

const ARABIC_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];

export function currentMonthStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

export function monthLabel(m: string): string {
  if (!m) return "";
  const [y, mm] = m.split("-");
  const idx = parseInt(mm, 10) - 1;
  return `${ARABIC_MONTHS[idx] || ""} ${y}`;
}

export function formatDate(d: string): string {
  if (!d) return "";
  const [, m, day] = d.split("-");
  const idx = parseInt(m, 10) - 1;
  return `${day} ${ARABIC_MONTHS[idx] || m}`;
}

export function formatMoney(n: number | null | undefined): string {
  const v = Number(n) || 0;
  return `${v.toLocaleString("en-US", { maximumFractionDigits: 2 })} ج.م`;
}

/** A doctor's monthly pay before bonus/deductions/advance: either
 * shiftRate x shifts worked, or percentageRate% of the month's revenue
 * (total value of cases/studies), depending on how that doctor is paid. */
export function computeDoctorBasePay(
  e: Pick<Employee, "payType" | "shiftRate" | "percentageRate">,
  p: Partial<Pick<PayrollEntry, "shifts" | "revenue">>
): number {
  if (e.payType === "percentage") {
    const revenue = Number(p.revenue) || 0;
    const rate = Number(e.percentageRate) || 0;
    return (revenue * rate) / 100;
  }
  const shiftRate = Number(e.shiftRate) || 0;
  const shifts = Number(p.shifts) || 0;
  return shiftRate * shifts;
}

/** Full net salary for one employee in one month. */
export function computeNet(
  e: Pick<Employee, "role" | "payType" | "baseSalary" | "shiftRate" | "percentageRate">,
  p: Partial<Pick<PayrollEntry, "shifts" | "revenue" | "bonus" | "deductions" | "advance">>
): number {
  const basePay = e.role === "doctor" ? computeDoctorBasePay(e, p) : Number(e.baseSalary) || 0;
  const bonus = Number(p.bonus) || 0;
  const deductions = Number(p.deductions) || 0;
  const advance = Number(p.advance) || 0;
  return basePay + bonus - deductions - advance;
}
