export type Role = "doctor" | "staff";
export type PayType = "shift" | "percentage" | null;

export interface Employee {
  id: string;
  name: string;
  role: Role;
  payType: PayType;
  baseSalary: number;
  shiftRate: number;
  percentageRate: number;
  phone: string;
  active: boolean;
  createdAt: string;
}

export interface PayrollEntry {
  id: string;
  employeeId: string;
  month: string; // 'YYYY-MM'
  shifts: number;
  revenue: number;
  bonus: number;
  deductions: number;
  advance: number;
  updatedAt: string;
}

export type ExpenseType =
  | "damaged"
  | "paper"
  | "supplies"
  | "maintenance"
  | "utilities"
  | "other";

export interface Expense {
  id: string;
  date: string; // 'YYYY-MM-DD'
  type: ExpenseType;
  description: string;
  amount: number;
  createdAt: string;
}

export const EXPENSE_TYPES: { id: ExpenseType; ar: string; color: string }[] = [
  { id: "damaged", ar: "تالف/كسر", color: "#E11D48" },
  { id: "paper", ar: "ورق ومطبوعات", color: "#075985" },
  { id: "supplies", ar: "مستلزمات طبية", color: "#065F46" },
  { id: "maintenance", ar: "صيانة أجهزة", color: "#92400E" },
  { id: "utilities", ar: "كهرباء ومياه ونت", color: "#5B21B6" },
  { id: "other", ar: "أخرى", color: "#64748B" },
];
