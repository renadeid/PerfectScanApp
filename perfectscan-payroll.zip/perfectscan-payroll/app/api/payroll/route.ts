import { NextRequest, NextResponse } from "next/server";
import { listPayrollEntries, upsertPayrollEntry } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const entries = await listPayrollEntries();
    return NextResponse.json({ entries });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to load payroll" }, { status: 500 });
  }
}

/** Upsert the one payroll row for (employeeId, month). Doubles as create/update. */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const employeeId = String(body.employeeId ?? "");
    const month = String(body.month ?? "");
    if (!employeeId || !/^\d{4}-\d{2}$/.test(month)) {
      return NextResponse.json({ error: "employeeId و month (YYYY-MM) مطلوبين" }, { status: 400 });
    }
    const entry = await upsertPayrollEntry({
      employeeId,
      month,
      shifts: Number(body.shifts) || 0,
      revenue: Number(body.revenue) || 0,
      bonus: Number(body.bonus) || 0,
      deductions: Number(body.deductions) || 0,
      advance: Number(body.advance) || 0,
    });
    return NextResponse.json({ entry });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to save payroll entry" }, { status: 500 });
  }
}
