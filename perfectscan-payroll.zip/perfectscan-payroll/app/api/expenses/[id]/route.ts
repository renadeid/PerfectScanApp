import { NextRequest, NextResponse } from "next/server";
import { deleteExpense, updateExpense } from "@/lib/db";
import { EXPENSE_TYPES, type ExpenseType } from "@/lib/types";

export const dynamic = "force-dynamic";

const VALID_TYPES = new Set(EXPENSE_TYPES.map((t) => t.id));

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const amount = Number(body.amount) || 0;
    if (amount <= 0) {
      return NextResponse.json({ error: "المبلغ يجب أن يكون أكبر من صفر" }, { status: 400 });
    }
    const type: ExpenseType = VALID_TYPES.has(body.type) ? body.type : "other";
    const expense = await updateExpense(id, {
      date: String(body.date ?? "").trim(),
      type,
      description: String(body.description ?? "").trim(),
      amount,
    });
    if (!expense) {
      return NextResponse.json({ error: "المصروف غير موجود" }, { status: 404 });
    }
    return NextResponse.json({ expense });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to update expense" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await deleteExpense(id);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to delete expense" }, { status: 500 });
  }
}
