import { NextRequest, NextResponse } from "next/server";
import { createExpense, listExpenses } from "@/lib/db";
import { EXPENSE_TYPES, type ExpenseType } from "@/lib/types";

export const dynamic = "force-dynamic";

const VALID_TYPES = new Set(EXPENSE_TYPES.map((t) => t.id));

export async function GET() {
  try {
    const expenses = await listExpenses();
    return NextResponse.json({ expenses });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to load expenses" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const amount = Number(body.amount) || 0;
    if (amount <= 0) {
      return NextResponse.json({ error: "المبلغ يجب أن يكون أكبر من صفر" }, { status: 400 });
    }
    const type: ExpenseType = VALID_TYPES.has(body.type) ? body.type : "other";
    const expense = await createExpense({
      date: String(body.date ?? "").trim() || new Date().toISOString().slice(0, 10),
      type,
      description: String(body.description ?? "").trim(),
      amount,
    });
    return NextResponse.json({ expense }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to create expense" }, { status: 500 });
  }
}
