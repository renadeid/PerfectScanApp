import { NextRequest, NextResponse } from "next/server";
import { createEmployee, listEmployees } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const employees = await listEmployees();
    return NextResponse.json({ employees });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to load employees" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "الاسم مطلوب" }, { status: 400 });
    }
    const role = body.role === "doctor" ? "doctor" : "staff";
    const payType = role === "doctor" ? (body.payType === "percentage" ? "percentage" : "shift") : null;
    const employee = await createEmployee({
      name,
      role,
      payType,
      baseSalary: Number(body.baseSalary) || 0,
      shiftRate: Number(body.shiftRate) || 0,
      percentageRate: Number(body.percentageRate) || 0,
      phone: String(body.phone ?? "").trim(),
      active: body.active !== false,
    });
    return NextResponse.json({ employee }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to create employee" }, { status: 500 });
  }
}
