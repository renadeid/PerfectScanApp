import { NextRequest, NextResponse } from "next/server";
import { deleteEmployee, updateEmployee } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "الاسم مطلوب" }, { status: 400 });
    }
    const role = body.role === "doctor" ? "doctor" : "staff";
    const payType = role === "doctor" ? (body.payType === "percentage" ? "percentage" : "shift") : null;
    const employee = await updateEmployee(id, {
      name,
      role,
      payType,
      baseSalary: Number(body.baseSalary) || 0,
      shiftRate: Number(body.shiftRate) || 0,
      percentageRate: Number(body.percentageRate) || 0,
      phone: String(body.phone ?? "").trim(),
      active: body.active !== false,
    });
    if (!employee) {
      return NextResponse.json({ error: "الموظف غير موجود" }, { status: 404 });
    }
    return NextResponse.json({ employee });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to update employee" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await deleteEmployee(id);
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Failed to delete employee" }, { status: 500 });
  }
}
