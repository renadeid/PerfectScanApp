import { NextResponse } from "next/server";
import { ping } from "@/lib/db";

export const dynamic = "force-dynamic";

/** GET /api/health — quick way to confirm the deployed app can reach its
 * database (open it in the browser, or `curl` it, right after deploying). */
export async function GET() {
  try {
    await ping();
    return NextResponse.json({ ok: true, database: "connected" });
  } catch (err: any) {
    return NextResponse.json(
      { ok: false, database: "unreachable", error: err.message ?? String(err) },
      { status: 500 }
    );
  }
}
