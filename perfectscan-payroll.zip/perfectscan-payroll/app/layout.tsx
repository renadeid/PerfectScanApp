import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "رواتب PerfectScan",
  description:
    "إدارة رواتب موظفي وأطباء مركز PerfectScan للأشعة، مع حساب صافي المرتب تلقائيًا وتسجيل المصروفات اليومية.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
