"use client";

import { createContext, useCallback, useContext, useRef, useState } from "react";
import { Icon } from "./icons";

type Toast = { id: number; message: string; error?: boolean };
type ToastFn = (message: string, error?: boolean) => void;

const ToastContext = createContext<ToastFn>(() => {});

export function useToast() {
  return useContext(ToastContext);
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const idRef = useRef(0);

  const push = useCallback<ToastFn>((message, error) => {
    const id = ++idRef.current;
    setToasts((t) => [...t, { id, message, error }]);
    setTimeout(() => {
      setToasts((t) => t.filter((x) => x.id !== id));
    }, 2600);
  }, []);

  return (
    <ToastContext.Provider value={push}>
      {children}
      <div id="toast-root">
        {toasts.map((t) => (
          <div key={t.id} className={"toast" + (t.error ? " error" : "")}>
            {!t.error && <Icon name="check" />}
            <span>{t.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
