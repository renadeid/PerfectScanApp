"use client";

const PATHS: Record<string, string> = {
  dashboard:
    '<rect x="3" y="3" width="7" height="7" rx="1.5"></rect><rect x="14" y="3" width="7" height="7" rx="1.5"></rect><rect x="3" y="14" width="7" height="7" rx="1.5"></rect><rect x="14" y="14" width="7" height="7" rx="1.5"></rect>',
  users:
    '<circle cx="9" cy="8" r="3.2"></circle><path d="M3.5 20c0-3.3 2.6-5.5 5.9-5.5S15.2 16.7 15.2 20"></path><circle cx="17" cy="8.5" r="2.6"></circle><path d="M15.8 14.7c2.6.3 4.7 2.3 4.7 5.3"></path>',
  wallet:
    '<rect x="3" y="6" width="18" height="13" rx="2.2"></rect><path d="M3 10h18"></path><circle cx="16.5" cy="14.2" r="1.1" fill="currentColor" stroke="none"></circle><path d="M7 6V5.3A2.3 2.3 0 0 1 9.3 3h5.4A2.3 2.3 0 0 1 17 5.3V6"></path>',
  receipt:
    '<path d="M6 3h12v17.5l-2.3-1.4-2.3 1.4-2.4-1.4-2.4 1.4-2.3-1.4L6 20.5z"></path><path d="M9 8h6M9 11.5h6M9 15h4"></path>',
  plus: '<path d="M12 5v14M5 12h14"></path>',
  edit:
    '<path d="M4 20l.8-3.6L15.4 5.8a1.7 1.7 0 0 1 2.4 0l1.4 1.4a1.7 1.7 0 0 1 0 2.4L8.6 20.2 4 20Z"></path><path d="M13.7 7.5l2.8 2.8"></path>',
  trash:
    '<path d="M4.5 6.5h15"></path><path d="M9 6.5V5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 5v1.5"></path><path d="M6.5 6.5l.9 12a2 2 0 0 0 2 1.9h5.2a2 2 0 0 0 2-1.9l.9-12"></path><path d="M10 10.5v6M14 10.5v6"></path>',
  close: '<path d="M6 6l12 12M18 6L6 18"></path>',
  check: '<path d="M5 13l4.5 4.5L19 7"></path>',
  printer:
    '<path d="M6.5 8.5V4h11v4.5"></path><rect x="3.5" y="8.5" width="17" height="8" rx="1.6"></rect><path d="M6.5 15h11v5h-11z"></path><path d="M7 12h1.4"></path>',
  trendingUp: '<path d="M3.5 16.5l6-6 4 4 6.5-7"></path><path d="M15.5 7h4.5v4.5"></path>',
  box: '<path d="M3.5 8.2L12 3.5l8.5 4.7V16L12 20.5 3.5 16z"></path><path d="M3.7 8.2L12 12.8l8.3-4.6"></path><path d="M12 12.8V20.5"></path>',
  stethoscope:
    '<path d="M6 3.5v5a3.5 3.5 0 0 0 7 0v-5"></path><path d="M6 3.5H4.5M13 3.5h1.5"></path><path d="M9.5 12v2.5a5 5 0 0 0 10 0v-1.3"></path><circle cx="19.5" cy="12.2" r="1.7"></circle>',
  staff: '<circle cx="12" cy="8" r="3.6"></circle><path d="M4.5 20c0-3.9 3.1-6.5 7.5-6.5s7.5 2.6 7.5 6.5"></path>',
};

export function Icon({ name, className }: { name: keyof typeof PATHS | string; className?: string }) {
  const d = PATHS[name];
  if (!d) return null;
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      dangerouslySetInnerHTML={{ __html: d }}
    />
  );
}
