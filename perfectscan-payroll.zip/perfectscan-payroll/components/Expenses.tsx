"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { ExpenseModal, type ExpenseInput } from "./ExpenseModal";
import { ConfirmModal } from "./ConfirmModal";
import { currentMonthStr, formatDate, formatMoney, monthLabel } from "@/lib/calc";
import { EXPENSE_TYPES, type Expense } from "@/lib/types";

export function Expenses({
  expenses,
  onCreate,
  onUpdate,
  onDelete,
}: {
  expenses: Expense[];
  onCreate: (input: ExpenseInput) => Promise<void>;
  onUpdate: (id: string, input: ExpenseInput) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}) {
  const [month, setMonth] = useState(currentMonthStr());
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Expense | null>(null);
  const [deleting, setDeleting] = useState<Expense | null>(null);

  const monthList = expenses
    .filter((x) => (x.date || "").slice(0, 7) === month)
    .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  const total = monthList.reduce((s, x) => s + (Number(x.amount) || 0), 0);

  const byType: Record<string, number> = {};
  monthList.forEach((x) => {
    byType[x.type] = (byType[x.type] || 0) + (Number(x.amount) || 0);
  });
  let topType: string | null = null;
  let topVal = 0;
  Object.keys(byType).forEach((k) => {
    if (byType[k] > topVal) {
      topVal = byType[k];
      topType = k;
    }
  });
  const topTypeLabel = topType ? EXPENSE_TYPES.find((t) => t.id === topType)?.ar ?? "—" : "—";
  const dayCount = new Set(monthList.map((x) => x.date)).size || 1;

  const stats = [
    {
      label: `إجمالي مصروفات ${monthLabel(month)}`,
      value: formatMoney(total),
      note: `${monthList.length} عملية مصروف`,
      icon: "receipt",
      cls: "stat-accent",
    },
    {
      label: "أكبر بند مصروف",
      value: topTypeLabel,
      note: topType ? formatMoney(topVal) : "لا يوجد مصروفات بعد",
      icon: "box",
      cls: "",
    },
    {
      label: "متوسط المصروف اليومي",
      value: formatMoney(monthList.length ? total / dayCount : 0),
      note: "لكل يوم فيه مصروف مسجل",
      icon: "trendingUp",
      cls: "",
    },
  ];

  return (
    <section>
      <div className="page-header">
        <div>
          <h1 className="page-title">المصروفات اليومية</h1>
          <p className="page-sub">تسجيل التوالف والمستلزمات وأي مصروف يومي بالمركز</p>
        </div>
        <div className="header-actions">
          <input
            type="month"
            className="month-input"
            value={month}
            onChange={(e) => setMonth(e.target.value || currentMonthStr())}
          />
          <button
            className="btn btn-brand"
            onClick={() => {
              setEditing(null);
              setModalOpen(true);
            }}
          >
            <Icon name="plus" />
            <span>إضافة مصروف</span>
          </button>
        </div>
      </div>

      <div className="stat-grid cols-3">
        {stats.map((s) => (
          <div className={"stat-card " + s.cls} key={s.label}>
            <div className="stat-label">
              <Icon name={s.icon} />
              <span>{s.label}</span>
            </div>
            <div className="stat-value">{s.value}</div>
            <div className="stat-note">{s.note}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="card-body" style={{ padding: 0 }}>
          {monthList.length === 0 ? (
            <div className="empty">
              <Icon name="receipt" />
              <div className="title">لا يوجد مصروفات مسجلة لشهر {monthLabel(month)}</div>
              <div>سجلي أول مصروف بالضغط على &quot;إضافة مصروف&quot;</div>
            </div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>التاريخ</th>
                    <th>النوع</th>
                    <th>الوصف</th>
                    <th className="num">المبلغ</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {monthList.map((x) => {
                    const t = EXPENSE_TYPES.find((t) => t.id === x.type) ?? EXPENSE_TYPES[EXPENSE_TYPES.length - 1];
                    return (
                      <tr key={x.id}>
                        <td className="cell-sub">{formatDate(x.date)}</td>
                        <td>
                          <span className="expense-type-pill">
                            <span className="dot" style={{ background: t.color }}></span>
                            {t.ar}
                          </span>
                        </td>
                        <td>{x.description || "—"}</td>
                        <td className="num">{formatMoney(x.amount)}</td>
                        <td className="actions">
                          <button
                            className="btn btn-ghost"
                            title="تعديل"
                            onClick={() => {
                              setEditing(x);
                              setModalOpen(true);
                            }}
                          >
                            <Icon name="edit" />
                          </button>{" "}
                          <button className="btn btn-ghost danger" title="حذف" onClick={() => setDeleting(x)}>
                            <Icon name="trash" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={3}>إجمالي مصروفات {monthLabel(month)}</td>
                    <td className="num">{formatMoney(total)}</td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      </div>

      {modalOpen && (
        <ExpenseModal
          existing={editing}
          onClose={() => setModalOpen(false)}
          onSave={async (input) => {
            if (editing) await onUpdate(editing.id, input);
            else await onCreate(input);
          }}
        />
      )}

      {deleting && (
        <ConfirmModal
          title="حذف المصروف"
          message={`هل أنتِ متأكدة من حذف مصروف "${
            EXPENSE_TYPES.find((t) => t.id === deleting.type)?.ar ?? ""
          }" بقيمة ${formatMoney(deleting.amount)}؟`}
          confirmLabel="حذف نهائي"
          onClose={() => setDeleting(null)}
          onConfirm={() => onDelete(deleting.id)}
        />
      )}
    </section>
  );
}
