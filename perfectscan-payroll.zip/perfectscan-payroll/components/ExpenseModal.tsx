"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { todayStr } from "@/lib/calc";
import { EXPENSE_TYPES, type Expense, type ExpenseType } from "@/lib/types";

export interface ExpenseInput {
  date: string;
  type: ExpenseType;
  description: string;
  amount: number;
}

export function ExpenseModal({
  existing,
  onSave,
  onClose,
}: {
  existing: Expense | null;
  onSave: (input: ExpenseInput) => Promise<void>;
  onClose: () => void;
}) {
  const isEdit = !!existing;
  const [date, setDate] = useState(existing?.date ?? todayStr());
  const [type, setType] = useState<ExpenseType>(existing?.type ?? "other");
  const [description, setDescription] = useState(existing?.description ?? "");
  const [amount, setAmount] = useState<string>(existing ? String(existing.amount) : "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleSave() {
    const amountVal = Number(amount) || 0;
    if (amountVal <= 0) {
      setError("من فضلك اكتبي قيمة المصروف");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await onSave({ date: date || todayStr(), type, description: description.trim(), amount: amountVal });
      onClose();
    } catch (err: any) {
      setError(err.message ?? "حصل خطأ أثناء الحفظ، حاولي تاني");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className="modal-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="modal">
        <div className="modal-header">
          <h3 className="section-heading">{isEdit ? "تعديل المصروف" : "إضافة مصروف يومي"}</h3>
          <button className="btn btn-ghost" onClick={onClose} aria-label="إغلاق">
            <Icon name="close" />
          </button>
        </div>

        <div className="field">
          <label htmlFor="x-date">التاريخ</label>
          <input id="x-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>

        <div className="field">
          <label htmlFor="x-type">نوع المصروف</label>
          <select id="x-type" value={type} onChange={(e) => setType(e.target.value as ExpenseType)}>
            {EXPENSE_TYPES.map((t) => (
              <option key={t.id} value={t.id}>
                {t.ar}
              </option>
            ))}
          </select>
        </div>

        <div className="field">
          <label htmlFor="x-desc">الوصف</label>
          <textarea
            id="x-desc"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="مثال: ورق طباعة تقارير - كرتونة"
          />
        </div>

        <div className="field">
          <label htmlFor="x-amount">المبلغ (ج.م)</label>
          <input
            id="x-amount"
            type="number"
            min={0}
            step="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0"
          />
        </div>

        {error && <div style={{ color: "var(--danger)", fontSize: 13 }}>{error}</div>}

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            إلغاء
          </button>
          <button className="btn btn-brand" disabled={busy} onClick={handleSave}>
            {isEdit ? "حفظ التعديلات" : "إضافة المصروف"}
          </button>
        </div>
      </div>
    </div>
  );
}
