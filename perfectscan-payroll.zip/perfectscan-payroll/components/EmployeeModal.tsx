"use client";

import { useState } from "react";
import { Icon } from "./icons";
import type { Employee, PayType, Role } from "@/lib/types";

export interface EmployeeInput {
  name: string;
  role: Role;
  payType: PayType;
  baseSalary: number;
  shiftRate: number;
  percentageRate: number;
  phone: string;
  active: boolean;
}

function rateFieldMeta(role: Role, payType: PayType) {
  if (role === "doctor") {
    if (payType === "percentage") {
      return {
        label: "النسبة من إجمالي قيمة الحالات (%)",
        hint: "هيتحسب أجره الشهري كنسبة من إجمالي قيمة الحالات اللي هتسجليها كل شهر في تبويب الرواتب الشهرية",
        max: 100,
        step: "0.1",
      };
    }
    return {
      label: "أجر الشفت الواحد (ج.م)",
      hint: "هيتحسب أجره الشهري حسب عدد الشفتات اللي هتسجليها لكل شهر في تبويب الرواتب الشهرية",
      max: undefined as number | undefined,
      step: "0.01",
    };
  }
  return {
    label: "المرتب الشهري الأساسي (ج.م)",
    hint: "مرتب ثابت شهريًا بغض النظر عن عدد أيام العمل",
    max: undefined as number | undefined,
    step: "0.01",
  };
}

export function EmployeeModal({
  existing,
  onSave,
  onClose,
}: {
  existing: Employee | null;
  onSave: (input: EmployeeInput) => Promise<void>;
  onClose: () => void;
}) {
  const isEdit = !!existing;
  const [name, setName] = useState(existing?.name ?? "");
  const [role, setRole] = useState<Role>(existing?.role ?? "staff");
  const [payType, setPayType] = useState<PayType>(
    existing?.role === "doctor" ? (existing?.payType === "percentage" ? "percentage" : "shift") : "shift"
  );
  const [rateValue, setRateValue] = useState<string>(() => {
    if (!existing) return "";
    if (existing.role === "doctor") {
      return String(existing.payType === "percentage" ? existing.percentageRate || "" : existing.shiftRate || "");
    }
    return String(existing.baseSalary || "");
  });
  const [phone, setPhone] = useState(existing?.phone ?? "");
  const [active, setActive] = useState(existing?.active !== false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const meta = rateFieldMeta(role, payType);

  function handleRoleChange(next: Role) {
    setRole(next);
    setPayType("shift");
    setRateValue("");
  }
  function handlePayTypeChange(next: PayType) {
    setPayType(next);
    setRateValue("");
  }

  async function handleSave() {
    const trimmedName = name.trim();
    if (!trimmedName) {
      setError("من فضلك اكتبي اسم الموظف");
      return;
    }
    const rateVal = Number(rateValue) || 0;
    const input: EmployeeInput = {
      name: trimmedName,
      role,
      payType: role === "doctor" ? payType : null,
      baseSalary: role === "staff" ? rateVal : 0,
      shiftRate: role === "doctor" && payType === "shift" ? rateVal : 0,
      percentageRate: role === "doctor" && payType === "percentage" ? rateVal : 0,
      phone: phone.trim(),
      active,
    };
    setBusy(true);
    setError("");
    try {
      await onSave(input);
      onClose();
    } catch (err: any) {
      setError(err.message ?? "حصل خطأ أثناء الحفظ، حاولي تاني");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className="modal-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="modal">
        <div className="modal-header">
          <h3 className="section-heading">{isEdit ? "تعديل بيانات الموظف" : "إضافة موظف جديد"}</h3>
          <button className="btn btn-ghost" onClick={onClose} aria-label="إغلاق">
            <Icon name="close" />
          </button>
        </div>

        <div className="field">
          <label htmlFor="f-name">الاسم بالكامل</label>
          <input
            id="f-name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="مثال: د. أحمد فتحي"
          />
        </div>

        <div className="field">
          <label htmlFor="f-role">الوظيفة</label>
          <select id="f-role" value={role} onChange={(e) => handleRoleChange(e.target.value as Role)}>
            <option value="staff">موظف (مرتب شهري ثابت)</option>
            <option value="doctor">دكتور تقارير</option>
          </select>
        </div>

        {role === "doctor" && (
          <div className="field">
            <label htmlFor="f-paytype">طريقة حساب أجر الدكتور</label>
            <select
              id="f-paytype"
              value={payType ?? "shift"}
              onChange={(e) => handlePayTypeChange(e.target.value as PayType)}
            >
              <option value="shift">أجر ثابت لكل شفت</option>
              <option value="percentage">نسبة % من إجمالي قيمة الحالات</option>
            </select>
          </div>
        )}

        <div className="field">
          <label htmlFor="f-rate-value">{meta.label}</label>
          <input
            id="f-rate-value"
            type="number"
            min={0}
            max={meta.max}
            step={meta.step}
            value={rateValue}
            onChange={(e) => setRateValue(e.target.value)}
            placeholder="0"
          />
          <div className="hint">{meta.hint}</div>
        </div>

        <div className="field">
          <label htmlFor="f-phone">رقم الهاتف (اختياري)</label>
          <input
            id="f-phone"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="01xxxxxxxxx"
          />
        </div>

        <div className="switch-row">
          <div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>حالة الموظف نشط</div>
            <div className="hint">أوقفي التفعيل بدل الحذف لو الموظف ترك العمل، عشان يفضل سجل رواتبه القديم محفوظ</div>
          </div>
          <label className="switch">
            <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
            <span className="track"></span>
            <span className="knob"></span>
          </label>
        </div>

        {error && <div style={{ color: "var(--danger)", fontSize: 13 }}>{error}</div>}

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            إلغاء
          </button>
          <button className="btn btn-brand" disabled={busy} onClick={handleSave}>
            {isEdit ? "حفظ التعديلات" : "إضافة الموظف"}
          </button>
        </div>
      </div>
    </div>
  );
}
