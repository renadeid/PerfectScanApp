"use client";

import { useEffect, useRef, useState } from "react";
import { Icon } from "./icons";
import { computeDoctorBasePay, computeNet, currentMonthStr, formatMoney, monthLabel } from "@/lib/calc";
import type { Employee, PayrollEntry } from "@/lib/types";

type PayrollFields = { shifts: number; revenue: number; bonus: number; deductions: number; advance: number };

const EMPTY: PayrollFields = { shifts: 0, revenue: 0, bonus: 0, deductions: 0, advance: 0 };

function PayrollRow({
  employee,
  entry,
  onSave,
}: {
  employee: Employee;
  entry: PayrollEntry | undefined;
  onSave: (fields: PayrollFields) => Promise<void>;
}) {
  const [fields, setFields] = useState<PayrollFields>({
    shifts: entry?.shifts ?? 0,
    revenue: entry?.revenue ?? 0,
    bonus: entry?.bonus ?? 0,
    deductions: entry?.deductions ?? 0,
    advance: entry?.advance ?? 0,
  });
  const [saved, setSaved] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Re-sync when the underlying entry changes (e.g. month switch).
  useEffect(() => {
    setFields({
      shifts: entry?.shifts ?? 0,
      revenue: entry?.revenue ?? 0,
      bonus: entry?.bonus ?? 0,
      deductions: entry?.deductions ?? 0,
      advance: entry?.advance ?? 0,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entry?.id, employee.id, entry?.month]);

  function change(field: keyof PayrollFields, value: string) {
    const next = { ...fields, [field]: value === "" ? 0 : Number(value) };
    setFields(next);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      await onSave(next);
      setSaved(true);
      setTimeout(() => setSaved(false), 1200);
    }, 550);
  }

  const isDoctor = employee.role === "doctor";
  const isPct = isDoctor && employee.payType === "percentage";
  const basePay = isDoctor ? computeDoctorBasePay(employee, fields) : 0;
  const net = computeNet(employee, fields);

  return (
    <tr>
      <td>
        <div className="cell-name">{employee.name}</div>
        <div className="cell-sub">{isDoctor ? "دكتور تقارير" : "موظف"}</div>
      </td>
      <td className="num">
        {isDoctor ? (isPct ? `${employee.percentageRate || 0}%` : `${formatMoney(employee.shiftRate)}/شفت`) : formatMoney(employee.baseSalary)}
      </td>
      <td className="num">
        {!isDoctor ? (
          <span className="cell-sub">—</span>
        ) : isPct ? (
          <>
            <input
              type="number"
              min={0}
              step="0.01"
              className="num-input"
              value={fields.revenue || ""}
              placeholder="0"
              onChange={(e) => change("revenue", e.target.value)}
            />
            <div className="cell-sub" style={{ marginTop: 4 }}>
              قيمة الحالات ج.م
            </div>
          </>
        ) : (
          <>
            <input
              type="number"
              min={0}
              step="1"
              className="num-input"
              value={fields.shifts || ""}
              placeholder="0"
              onChange={(e) => change("shifts", e.target.value)}
            />
            <div className="cell-sub" style={{ marginTop: 4 }}>
              عدد الشفتات
            </div>
          </>
        )}
      </td>
      <td className="num">{isDoctor ? formatMoney(basePay) : <span className="cell-sub">—</span>}</td>
      <td className="num">
        <input
          type="number"
          min={0}
          step="0.01"
          className="num-input"
          value={fields.bonus || ""}
          placeholder="0"
          onChange={(e) => change("bonus", e.target.value)}
        />
      </td>
      <td className="num">
        <input
          type="number"
          min={0}
          step="0.01"
          className="num-input"
          value={fields.deductions || ""}
          placeholder="0"
          onChange={(e) => change("deductions", e.target.value)}
        />
      </td>
      <td className="num">
        <input
          type="number"
          min={0}
          step="0.01"
          className="num-input"
          value={fields.advance || ""}
          placeholder="0"
          onChange={(e) => change("advance", e.target.value)}
        />
      </td>
      <td className="num net-cell" style={{ color: net < 0 ? "var(--danger)" : "var(--brand)" }}>
        {formatMoney(net)}
        <span className={"save-flag" + (saved ? " show" : "")}></span>
      </td>
    </tr>
  );
}

export function Payroll({
  employees,
  payrollEntries,
  onSaveEntry,
}: {
  employees: Employee[];
  payrollEntries: PayrollEntry[];
  onSaveEntry: (employeeId: string, month: string, fields: PayrollFields) => Promise<void>;
}) {
  const [month, setMonth] = useState(currentMonthStr());
  const active = employees.filter((e) => e.active !== false);

  const totalNet = active.reduce((s, e) => {
    const entry = payrollEntries.find((p) => p.employeeId === e.id && p.month === month);
    return s + computeNet(e, entry ?? EMPTY);
  }, 0);

  return (
    <section>
      <div className="page-header">
        <div>
          <h1 className="page-title">الرواتب الشهرية</h1>
          <p className="page-sub">مرتبات ثابتة للموظفين، وأجر بالشفت أو نسبة من الحالات للدكاترة، بعد الخصومات والبونص والسلف</p>
        </div>
        <div className="header-actions">
          <input
            type="month"
            className="month-input"
            value={month}
            onChange={(e) => setMonth(e.target.value || currentMonthStr())}
          />
          <button className="btn btn-secondary no-print" onClick={() => window.print()}>
            <Icon name="printer" />
            <span>طباعة كشف الرواتب</span>
          </button>
        </div>
      </div>

      <div className="card">
        <div className="card-body" style={{ padding: 0 }}>
          {active.length === 0 ? (
            <div className="empty">
              <Icon name="wallet" />
              <div className="title">لا يوجد موظفون نشطون</div>
              <div>أضيفي موظفين من تبويب &quot;الموظفون&quot; الأول عشان تقدري تحسبي رواتبهم</div>
            </div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>الموظف</th>
                    <th className="num">الأجر الثابت / النسبة</th>
                    <th className="num">الأساس الشهري</th>
                    <th className="num">الأجر المحسوب</th>
                    <th className="num">بونص</th>
                    <th className="num">خصومات</th>
                    <th className="num">سلفة</th>
                    <th className="num">صافي المرتب</th>
                  </tr>
                </thead>
                <tbody>
                  {active.map((e) => (
                    <PayrollRow
                      key={e.id + month}
                      employee={e}
                      entry={payrollEntries.find((p) => p.employeeId === e.id && p.month === month)}
                      onSave={(fields) => onSaveEntry(e.id, month, fields)}
                    />
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={7}>إجمالي صافي الرواتب لشهر {monthLabel(month)}</td>
                    <td className="num">{formatMoney(totalNet)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
