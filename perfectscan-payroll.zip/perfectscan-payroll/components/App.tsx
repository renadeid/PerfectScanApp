"use client";

import { useEffect, useState } from "react";
import { Icon } from "./icons";
import { ToastProvider, useToast } from "./ToastProvider";
import { Dashboard } from "./Dashboard";
import { Employees } from "./Employees";
import { Payroll } from "./Payroll";
import { Expenses } from "./Expenses";
import type { EmployeeInput } from "./EmployeeModal";
import type { ExpenseInput } from "./ExpenseModal";
import type { Employee, Expense, PayrollEntry } from "@/lib/types";

type Tab = "dashboard" | "employees" | "payroll" | "expenses";

const NAV_ITEMS: { id: Tab; label: string; icon: string }[] = [
  { id: "dashboard", label: "لوحة التحكم", icon: "dashboard" },
  { id: "employees", label: "الموظفون", icon: "users" },
  { id: "payroll", label: "الرواتب الشهرية", icon: "wallet" },
  { id: "expenses", label: "المصروفات اليومية", icon: "receipt" },
];

async function jsonOrThrow(res: Response) {
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || "حصل خطأ غير متوقع");
  return body;
}

function AppShell() {
  const [tab, setTab] = useState<Tab>("dashboard");
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payrollEntries, setPayrollEntries] = useState<PayrollEntry[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const toast = useToast();

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [e, p, x] = await Promise.all([
          fetch("/api/employees").then(jsonOrThrow),
          fetch("/api/payroll").then(jsonOrThrow),
          fetch("/api/expenses").then(jsonOrThrow),
        ]);
        if (cancelled) return;
        setEmployees(e.employees);
        setPayrollEntries(p.entries);
        setExpenses(x.expenses);
      } catch (err: any) {
        if (!cancelled) setLoadError(err.message || "تعذر الاتصال بقاعدة البيانات");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  async function createEmployee(input: EmployeeInput) {
    const { employee } = await jsonOrThrow(
      await fetch("/api/employees", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) })
    );
    setEmployees((list) => [...list, employee]);
    toast("تمت إضافة الموظف");
  }

  async function updateEmployee(id: string, input: EmployeeInput) {
    const { employee } = await jsonOrThrow(
      await fetch(`/api/employees/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) })
    );
    setEmployees((list) => list.map((e) => (e.id === id ? employee : e)));
    toast("تم حفظ التعديلات");
  }

  async function deleteEmployee(id: string) {
    await jsonOrThrow(await fetch(`/api/employees/${id}`, { method: "DELETE" }));
    setEmployees((list) => list.filter((e) => e.id !== id));
    setPayrollEntries((list) => list.filter((p) => p.employeeId !== id));
    toast("تم حذف الموظف");
  }

  async function savePayrollEntry(
    employeeId: string,
    month: string,
    fields: { shifts: number; revenue: number; bonus: number; deductions: number; advance: number }
  ) {
    try {
      const { entry } = await jsonOrThrow(
        await fetch("/api/payroll", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ employeeId, month, ...fields }),
        })
      );
      setPayrollEntries((list) => {
        const idx = list.findIndex((p) => p.employeeId === employeeId && p.month === month);
        if (idx >= 0) {
          const next = list.slice();
          next[idx] = entry;
          return next;
        }
        return [...list, entry];
      });
    } catch (err: any) {
      toast(err.message || "تعذر حفظ البيانات، حاولي تاني", true);
    }
  }

  async function createExpense(input: ExpenseInput) {
    const { expense } = await jsonOrThrow(
      await fetch("/api/expenses", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) })
    );
    setExpenses((list) => [expense, ...list]);
    toast("تمت إضافة المصروف");
  }

  async function updateExpense(id: string, input: ExpenseInput) {
    const { expense } = await jsonOrThrow(
      await fetch(`/api/expenses/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) })
    );
    setExpenses((list) => list.map((x) => (x.id === id ? expense : x)));
    toast("تم حفظ التعديلات");
  }

  async function deleteExpense(id: string) {
    await jsonOrThrow(await fetch(`/api/expenses/${id}`, { method: "DELETE" }));
    setExpenses((list) => list.filter((x) => x.id !== id));
    toast("تم حذف المصروف");
  }

  return (
    <div id="app">
      <aside className="sidebar">
        <div className="brand-row">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="brand-mark" src="/logo-mark.png" alt="PerfectScan" />
          <div className="brand-text">
            <span className="brand-name">PerfectScan</span>
            <span className="brand-sub">برفكت سكان</span>
          </div>
        </div>
        <nav className="nav">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              className={"nav-item" + (tab === item.id ? " active" : "")}
              onClick={() => setTab(item.id)}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="nav-footer">
          إدارة الرواتب والمصروفات
          <br />
          مركز برفكت سكان للأشعة
        </div>
      </aside>

      <main className="content">
        {loadError && (
          <div className="badge badge-demo" style={{ marginBottom: "var(--space-5)" }}>
            تعذر الاتصال بقاعدة البيانات: {loadError}. تأكدي إن POSTGRES_URL متظبط صح.
          </div>
        )}
        {loading ? (
          <p className="page-sub">بيتم تحميل البيانات...</p>
        ) : (
          <>
            {tab === "dashboard" && (
              <Dashboard employees={employees} payrollEntries={payrollEntries} expenses={expenses} />
            )}
            {tab === "employees" && (
              <Employees
                employees={employees}
                onCreate={createEmployee}
                onUpdate={updateEmployee}
                onDelete={deleteEmployee}
              />
            )}
            {tab === "payroll" && (
              <Payroll employees={employees} payrollEntries={payrollEntries} onSaveEntry={savePayrollEntry} />
            )}
            {tab === "expenses" && (
              <Expenses expenses={expenses} onCreate={createExpense} onUpdate={updateExpense} onDelete={deleteExpense} />
            )}
          </>
        )}
      </main>
    </div>
  );
}

export function App() {
  return (
    <ToastProvider>
      <AppShell />
    </ToastProvider>
  );
}
