"use client";

import { Icon } from "./icons";
import { computeNet, currentMonthStr, formatDate, formatMoney, monthLabel } from "@/lib/calc";
import { EXPENSE_TYPES, type Employee, type Expense, type PayrollEntry } from "@/lib/types";

function EmptyState({ icon, title, sub }: { icon: string; title: string; sub: string }) {
  return (
    <div className="empty">
      <Icon name={icon} />
      <div className="title">{title}</div>
      <div>{sub}</div>
    </div>
  );
}

export function Dashboard({
  employees,
  payrollEntries,
  expenses,
}: {
  employees: Employee[];
  payrollEntries: PayrollEntry[];
  expenses: Expense[];
}) {
  const active = employees.filter((e) => e.active !== false);
  const doctorsCount = active.filter((e) => e.role === "doctor").length;
  const staffCount = active.length - doctorsCount;
  const month = currentMonthStr();
  const monthPayroll = payrollEntries.filter((p) => p.month === month);
  const totalNet = active.reduce((s, e) => {
    const p = monthPayroll.find((x) => x.employeeId === e.id);
    return s + computeNet(e, p ?? {});
  }, 0);
  const monthExpenses = expenses.filter((x) => (x.date || "").slice(0, 7) === month);
  const totalExpenses = monthExpenses.reduce((s, x) => s + (Number(x.amount) || 0), 0);

  const stats = [
    {
      label: "إجمالي الفريق",
      value: String(active.length),
      note: `${doctorsCount} دكتور · ${staffCount} موظف`,
      icon: "users",
      cls: "",
    },
    {
      label: `صافي رواتب ${monthLabel(month)}`,
      value: formatMoney(totalNet),
      note: "لكل الفريق النشط هذا الشهر",
      icon: "wallet",
      cls: "stat-brand",
    },
    {
      label: `مصروفات ${monthLabel(month)}`,
      value: formatMoney(totalExpenses),
      note: `${monthExpenses.length} عملية مصروف`,
      icon: "receipt",
      cls: "stat-accent",
    },
    {
      label: "إجمالي المصروف الكلي",
      value: formatMoney(totalNet + totalExpenses),
      note: "رواتب + مصروفات الشهر",
      icon: "trendingUp",
      cls: "",
    },
  ];

  const recentExpenses = [...expenses].sort((a, b) => (b.date || "").localeCompare(a.date || "")).slice(0, 6);

  return (
    <section>
      <div className="page-header">
        <div>
          <h1 className="page-title">لوحة التحكم</h1>
          <p className="page-sub">نظرة عامة على رواتب الشهر ومصروفات المركز</p>
        </div>
      </div>

      <div className="stat-grid">
        {stats.map((s) => (
          <div className={"stat-card " + s.cls} key={s.label}>
            <div className="stat-label">
              <Icon name={s.icon} />
              <span>{s.label}</span>
            </div>
            <div className="stat-value">{s.value}</div>
            <div className="stat-note">{s.note}</div>
          </div>
        ))}
      </div>

      <div className="dashboard-grid">
        <div className="card">
          <div className="card-header">
            <h2 className="section-heading">صافي رواتب هذا الشهر</h2>
          </div>
          <div className="card-body">
            {active.length === 0 ? (
              <EmptyState icon="users" title="لسه مفيش موظفين" sub='ابدئي بإضافة أول موظف أو دكتور من تبويب "الموظفون"' />
            ) : (
              <div className="recent-list">
                {active.slice(0, 6).map((e) => {
                  const p = monthPayroll.find((x) => x.employeeId === e.id) ?? {};
                  const net = computeNet(e, p);
                  return (
                    <div className="recent-row" key={e.id}>
                      <div className="recent-main">
                        <div className="recent-icon">
                          <Icon name={e.role === "doctor" ? "stethoscope" : "staff"} />
                        </div>
                        <div>
                          <div className="cell-name">{e.name}</div>
                          <div className="cell-sub">{e.role === "doctor" ? "دكتور تقارير" : "موظف"}</div>
                        </div>
                      </div>
                      <div className="recent-amount" style={{ color: net < 0 ? "var(--danger)" : "var(--ink)" }}>
                        {formatMoney(net)}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h2 className="section-heading">أحدث المصروفات</h2>
          </div>
          <div className="card-body">
            {recentExpenses.length === 0 ? (
              <EmptyState icon="receipt" title="لسه مفيش مصروفات مسجلة" sub='سجلي أول مصروف يومي من تبويب "المصروفات اليومية"' />
            ) : (
              <div className="recent-list">
                {recentExpenses.map((x) => {
                  const t = EXPENSE_TYPES.find((t) => t.id === x.type) ?? EXPENSE_TYPES[EXPENSE_TYPES.length - 1];
                  return (
                    <div className="recent-row" key={x.id}>
                      <div className="recent-main">
                        <div className="recent-icon">
                          <Icon name="box" />
                        </div>
                        <div>
                          <div className="cell-name">{t.ar}</div>
                          <div className="cell-sub">
                            {x.description ? `${x.description} · ` : ""}
                            {formatDate(x.date)}
                          </div>
                        </div>
                      </div>
                      <div className="recent-amount">{formatMoney(x.amount)}</div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
