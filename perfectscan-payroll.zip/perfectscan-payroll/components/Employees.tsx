"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { EmployeeModal, type EmployeeInput } from "./EmployeeModal";
import { ConfirmModal } from "./ConfirmModal";
import { formatMoney } from "@/lib/calc";
import type { Employee } from "@/lib/types";

function rateDisplay(e: Employee): string {
  if (e.role === "doctor") {
    return e.payType === "percentage" ? `${e.percentageRate || 0}% من الحالات` : `${formatMoney(e.shiftRate)} / شفت`;
  }
  return `${formatMoney(e.baseSalary)} / شهريًا`;
}

export function Employees({
  employees,
  onCreate,
  onUpdate,
  onDelete,
}: {
  employees: Employee[];
  onCreate: (input: EmployeeInput) => Promise<void>;
  onUpdate: (id: string, input: EmployeeInput) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}) {
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);
  const [deleting, setDeleting] = useState<Employee | null>(null);

  const sorted = [...employees].sort((a, b) => {
    if ((a.active !== false) !== (b.active !== false)) return a.active !== false ? -1 : 1;
    return a.name.localeCompare(b.name, "ar");
  });

  return (
    <section>
      <div className="page-header">
        <div>
          <h1 className="page-title">الموظفون والأطباء</h1>
          <p className="page-sub">إضافة وتعديل بيانات الفريق العامل بالمركز</p>
        </div>
        <div className="header-actions">
          <button
            className="btn btn-brand"
            onClick={() => {
              setEditing(null);
              setModalOpen(true);
            }}
          >
            <Icon name="plus" />
            <span>إضافة موظف</span>
          </button>
        </div>
      </div>

      <div className="card">
        <div className="card-body" style={{ padding: 0 }}>
          {employees.length === 0 ? (
            <div className="empty">
              <Icon name="users" />
              <div className="title">لا يوجد موظفون بعد</div>
              <div>اضغطي على &quot;إضافة موظف&quot; لتبدئي تسجيل فريق المركز</div>
            </div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>الاسم</th>
                    <th>الوظيفة</th>
                    <th className="num">الأجر</th>
                    <th>الحالة</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((e) => (
                    <tr key={e.id}>
                      <td>
                        <div className="cell-name">{e.name}</div>
                        {e.phone && <div className="cell-sub">{e.phone}</div>}
                      </td>
                      <td>
                        <span className={"badge " + (e.role === "doctor" ? "badge-doctor" : "badge-staff")}>
                          <Icon name={e.role === "doctor" ? "stethoscope" : "staff"} />
                          {e.role === "doctor" ? "دكتور تقارير" : "موظف"}
                        </span>
                      </td>
                      <td className="num">{rateDisplay(e)}</td>
                      <td>
                        <span className={"badge " + (e.active !== false ? "badge-active" : "badge-inactive")}>
                          {e.active !== false ? "نشط" : "موقوف"}
                        </span>
                      </td>
                      <td className="actions">
                        <button
                          className="btn btn-ghost"
                          title="تعديل"
                          onClick={() => {
                            setEditing(e);
                            setModalOpen(true);
                          }}
                        >
                          <Icon name="edit" />
                        </button>{" "}
                        <button className="btn btn-ghost danger" title="حذف" onClick={() => setDeleting(e)}>
                          <Icon name="trash" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {modalOpen && (
        <EmployeeModal
          existing={editing}
          onClose={() => setModalOpen(false)}
          onSave={async (input) => {
            if (editing) await onUpdate(editing.id, input);
            else await onCreate(input);
          }}
        />
      )}

      {deleting && (
        <ConfirmModal
          title="حذف الموظف"
          message={`هل أنتِ متأكدة من حذف "${deleting.name}"؟ هيتحذف معاه سجل الرواتب الخاص بيه. الأفضل توقفي تفعيله بدل الحذف لو محتاجة تحتفظي بسجله.`}
          confirmLabel="حذف نهائي"
          onClose={() => setDeleting(null)}
          onConfirm={() => onDelete(deleting.id)}
        />
      )}
    </section>
  );
}
