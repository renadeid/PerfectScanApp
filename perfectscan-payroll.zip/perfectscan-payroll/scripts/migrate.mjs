// One-off schema migration: creates the employees / payroll_entries / expenses
// tables if they don't exist yet.
//
// Usage:
//   npm run db:migrate         (reads POSTGRES_URL / DATABASE_URL from .env)
//
// This is a convenience script. If it fails for any reason (some hosted
// Postgres providers restrict multi-statement queries over their pooled
// connection), just open db/schema.sql and run it in your provider's SQL
// editor (Neon, Supabase and the Vercel Postgres dashboard all have one).

import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));

async function main() {
  const connectionString = process.env.DATABASE_URL || process.env.POSTGRES_URL;
  if (!connectionString) {
    console.error(
      "No DATABASE_URL or POSTGRES_URL environment variable found.\n" +
        "Copy .env.example to .env and fill in a connection string first."
    );
    process.exit(1);
  }
  const { neon } = await import("@neondatabase/serverless");
  const sql = neon(connectionString);

  const schemaPath = join(__dirname, "..", "db", "schema.sql");
  const schema = readFileSync(schemaPath, "utf8");

  console.log("Running db/schema.sql against the configured database...");
  await sql.query(schema);
  console.log("Done. Tables are ready: employees, payroll_entries, expenses.");
}

main().catch((err) => {
  console.error("Migration failed:", err.message);
  console.error(
    "\nYou can instead paste the contents of db/schema.sql into your " +
      "Postgres provider's SQL editor and run it there."
  );
  process.exit(1);
});
